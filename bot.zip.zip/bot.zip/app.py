from aiohttp import web
from botbuilder.core import BotFrameworkAdapter, BotFrameworkAdapterSettings, TurnContext
from botbuilder.schema import Activity
import asyncio

# Define adapter settings with Microsoft App ID and password (optional, for authentication)
APP_ID = "ce28e427-6ce6-4638-82f4-f5dff5bb4db1"      # Replace with your Azure App ID (found in Azure Bot Services)
APP_PASSWORD = "W0G8Q~GmzG.vuRvnLrprwYkChVLsZbtY7kaPkbuo"  # Replace with your Azure App Password (found in Azure Bot Services)

# Initialize adapter with settings
adapter_settings = BotFrameworkAdapterSettings(APP_ID, APP_PASSWORD)
adapter = BotFrameworkAdapter(adapter_settings)

# A simple bot function that echoes back user messages
async def on_message(turn_context: TurnContext):
    await turn_context.send_activity(Activity(type="message", text=f"You said: {turn_context.activity.text}"))

# Message handler
async def messages_handler(request: web.Request):
    body = await request.json()
    activity = Activity().deserialize(body)
    auth_header = request.headers.get("Authorization", "")
    response = await adapter.process_activity(activity, auth_header, on_message)
    if response:
        return web.Response(status=response.status)
    return web.Response(status=200)

# Initialize the web server
app = web.Application()
app.router.add_post("/api/messages", messages_handler)

if __name__ == "__main__":
    web.run_app(app, port=3978)
